package main.java.com.api.util;

public enum credential {
    APP_BASE_URL,

    }
